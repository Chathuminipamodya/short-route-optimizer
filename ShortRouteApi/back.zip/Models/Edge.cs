﻿namespace ShortRouteApi.Models
{
    public class Edge
    {
        public string To { get; set; }
        public int Weight { get; set; }
    }
}